#include "EmptyHeap.h"

EmptyHeap::EmptyHeap(const char* msg) : std::runtime_error(msg)
{
  
}
