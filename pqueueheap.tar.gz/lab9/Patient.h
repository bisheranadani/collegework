#ifndef PATIENT_H
#define PATIENT_H

#include <string>
using namespace std;

class Patient
{
private:
  string m_name;
  int m_pin;

public:
  Patient();
  Patient(string name, int priority);

  string getName();
  int getPin();

  bool operator>(Patient rhs);
  bool operator<(Patient rhs);

};


#endif
