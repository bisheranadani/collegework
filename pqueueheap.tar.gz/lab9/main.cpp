#include "Executive.h"

#include <iostream>
#include <string>
#include <fstream>

using namespace std;

int main(int argc, char* argv[])
{
  // cout << "open" << "\n";

  if(argc >= 2)
  {
    Executive theExec(argv[1]);
  }
  else
  {
    cout << "Provide a filename as command line argument\n";
  }

  return(0);
}
