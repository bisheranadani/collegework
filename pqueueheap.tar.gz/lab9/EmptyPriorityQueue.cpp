#include "EmptyPriorityQueue.h"

EmptyPriorityQueue::EmptyPriorityQueue(const char* msg) : std::runtime_error(msg)
{

}
