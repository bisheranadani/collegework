#include "Heap.h"
#include <cstddef>

#include <iostream>

using namespace std;

template <typename T>
Heap<T>::Heap(int initialSize) : sizeOfArray(initialSize), numItemsInHeap(0)
{
  theCompleteBinaryTree = new T[sizeOfArray];

}

template <typename T>
Heap<T>::Heap(const Heap<T>& heap) : theCompleteBinaryTree(heap.sizeOfArray ? new T[heap.sizeOfArray] : nullptr), sizeOfArray(heap.sizeOfArray), numItemsInHeap(heap.numItemsInHeap)
{
  if(theCompleteBinaryTree && !(heap.isEmpty()))
  {
    for(int i=0; i < numItemsInHeap; i++)
    {
      // cout << "Copied entry \n";
      theCompleteBinaryTree[i] = heap.theCompleteBinaryTree[i];
    }
    // cout << "Copy constructor array size: " <<  sizeOfArray << "\n";
    // cout << "Copy constructor num items " << numItemsInHeap << "\n";
  }
}

template <typename T>
Heap<T>::~Heap()
{
  delete[] theCompleteBinaryTree;
}


template <typename T>
void Heap<T>::add(T& newItem)
{
  if(numItemsInHeap == sizeOfArray) //creates a new array if current array is full
  {
    T* temp = new T[sizeOfArray*2];

    for(int i = 0; i < numItemsInHeap; i++)
    {
      temp[i] = theCompleteBinaryTree[i];
    }

    delete[] theCompleteBinaryTree;

    theCompleteBinaryTree = temp;

    sizeOfArray = (sizeOfArray*2);

    // cout << "New array created size: " << sizeOfArray << "\n";
  }

  // cout << "Num items in heap: " << numItemsInHeap << "\n";
  theCompleteBinaryTree[numItemsInHeap] = newItem;
  // cout << "New Item added: " << theCompleteBinaryTree[numItemsInHeap] << "\n";

  bool inPlace = false;
  int newItemIndex, parentIndex;
  newItemIndex = numItemsInHeap;

  while(!inPlace)
  {
    if(newItemIndex != 0)
    {
      parentIndex = (newItemIndex - 1)/2;
      if(theCompleteBinaryTree[parentIndex] > theCompleteBinaryTree[newItemIndex])
      {
        inPlace = true;
      }
      else //upheaping
      {
        T temp = theCompleteBinaryTree[parentIndex];
        theCompleteBinaryTree[parentIndex] = theCompleteBinaryTree[newItemIndex];
        theCompleteBinaryTree[newItemIndex] = temp;

        newItemIndex = parentIndex;
        inPlace = false;
      }
    }
    else
    {
      inPlace = true;
    }
  }

  if(inPlace)
  {
    numItemsInHeap++;
  }

}

template <typename T>
bool Heap<T>::isEmpty() const
{
  bool res = false;

  // cout << "isEmpty test: ";
  // cout << sizeOfArray << " " << numItemsInHeap << "\n";
  if(!(sizeOfArray) || !(numItemsInHeap))
  {
    res = true;
  }

  return(res);
}

template <typename T>
void Heap<T>::remove() throw (EmptyHeap)
{
  if(isEmpty())
  {
    throw (EmptyHeap("Attempted remove on empty heap\n"));
  }
  else
  {
    theCompleteBinaryTree[0] = theCompleteBinaryTree[numItemsInHeap-1]; //removes root, replaces with last value
    numItemsInHeap--;

    downHeap(0);

    // cout << "Removed \n";
    // cout << "Num items in heap: " << numItemsInHeap << "\n";
  }
}

template <typename T>
void Heap<T>::downHeap(int rootIndex)
{
  if(!(isLeaf(rootIndex)))
  {

    int largerChildIndex = (2*rootIndex)+1;

    if(hasRightChild(rootIndex)) //finding the larger child
    {
      int rightChildIndex = largerChildIndex+1;
      if(theCompleteBinaryTree[rightChildIndex] > theCompleteBinaryTree[largerChildIndex]) largerChildIndex = rightChildIndex;
    }

    if(theCompleteBinaryTree[rootIndex] < theCompleteBinaryTree[largerChildIndex]) //after index is found, downHeap
    {
      T temp = theCompleteBinaryTree[rootIndex];
      theCompleteBinaryTree[rootIndex] = theCompleteBinaryTree[largerChildIndex];
      theCompleteBinaryTree[largerChildIndex] = (temp);

      downHeap(largerChildIndex);
    }
  }
}

template <typename T>
bool Heap<T>::isLeaf(int rootIndex)
{
  int leftchild = (2*rootIndex) + 1;
  // int righchild = (2*rootIndex) + 2;
  bool res = false;

  if(leftchild > (numItemsInHeap-1))
  {
    res = true;
  }

  return(res);
}

template <typename T>
bool Heap<T>::hasRightChild(int rootIndex)
{
  int righchild = (2*rootIndex) + 2;
  bool res = false;

  if(righchild <= (numItemsInHeap-1))
  {
    res = true;
  }

  return(res);
}

template <typename T>
T Heap<T>::peekTop() const throw (EmptyHeap)
{
  if(isEmpty())
  {
    throw (EmptyHeap("Attempted peek on empty heap\n"));
  }

  else
  {
    return(theCompleteBinaryTree[0]);
  }
}
