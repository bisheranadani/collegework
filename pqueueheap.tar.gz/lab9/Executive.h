#ifndef EXECUTIVE_H
#define EXECUTIVE_H

#include "PriorityQueue.h"
#include "Patient.h"

#include <fstream>
#include <string>
using namespace std;

class Executive
{
public:
  Executive(const char* fileName);
  void runSimulation();
  void preview(PriorityQueue<Patient> pq);
  ~Executive();

private:
  ifstream infile;
  PriorityQueue<Patient>* theQueue;
};

#endif
