#include "PriorityQueue.h"
#include <cstddef>

#include <iostream>

using namespace std;

template <typename T>
PriorityQueue<T>::PriorityQueue(int initialSize) : theHeap(new Heap<T>(initialSize))
{

}

template <typename T>
PriorityQueue<T>::PriorityQueue(const PriorityQueue<T>& pq) : theHeap(new Heap<T>(*(pq.theHeap)))
{

}

template <typename T>
PriorityQueue<T>::~PriorityQueue()
{
  delete theHeap;
}

template <typename T>
void PriorityQueue<T>::enqueue(T& newEntry)
{
  theHeap->add(newEntry);
}

template <typename T>
void PriorityQueue<T>::dequeue() throw (EmptyPriorityQueue)
{
  try
  {
    theHeap->remove();
  }
  catch(const exception& e)
  {
    throw(EmptyPriorityQueue("Error: Dequeue attempted on empty queue\n"));
  }
}

template <typename T>
bool PriorityQueue<T>::isEmpty() const
{
  return(theHeap->isEmpty());
}

template <typename T>
T PriorityQueue<T>::peekFront() const throw (EmptyPriorityQueue)
{
  try
  {
    T temp = theHeap->peekTop();
    return(temp);
  }
  catch(const exception& e)
  {
    throw(EmptyPriorityQueue("Error: Peek attempted on empty queue\n"));
  }
}
