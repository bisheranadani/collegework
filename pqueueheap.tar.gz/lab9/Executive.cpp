#include "Executive.h"
#include <string>
#include <fstream>


using namespace std;
#include <string>

Executive::Executive(const char* fileName)
{
  infile.open(fileName);

  if(infile.is_open())
  {
    runSimulation();
  }
  else
  {
    cout << "File did not open\n";
  }
  infile.close();
}

Executive::~Executive()
{
  if(theQueue != nullptr)
  {
    delete theQueue;
  }
}


void Executive::runSimulation()
{
  cout << "===============================\n";
  cout << "Welcome to Hospital Simulation\n";
  cout << "===============================\n";
  cout << "\n";

  int size = 0;
  infile >> size;

  if(size <= 0)
  {
    cout << "Invalid array size\n";
    return;
  }
  theQueue = new PriorityQueue<Patient>(size);

  while(!(infile.eof()))
  {
    string temp1, temp2;
    int temp3 = 0;

    infile >> temp1;
    if(temp1 == "arrival")
    {
      infile >> temp2;
      infile >> temp3;
      Patient tempPatient(temp2, temp3);

      cout << tempPatient.getName() << " with priority " << tempPatient.getPin() << " has arrived"<< "\n";

      theQueue->enqueue(tempPatient);
    }

    else if(temp1 == "serve")
    {
      try
      {
        cout << "Serving patient with highest priority...\n";
        theQueue->dequeue();
      }
      catch(const exception& e)
      {
        cout << e.what() << "\n";
      }
    }

    else if(temp1 == "preview")
    {
      cout << "Entering preview: \n";
      preview((*theQueue));
    }
    else
    {

    }
  }

  cout << "\n";
  cout << "=====Goodbye=====\n";
}

void Executive::preview(PriorityQueue<Patient> pq)
{
  cout << "\n";
  cout << "====Assuming no new arrivals, the current set of patients will be processed as follows====\n";

  while(!(pq.isEmpty()))
  {
    // cout << "loop\n";
    try
    {
      Patient temp = pq.peekFront();
      cout << temp.getName() << " with priority " << temp.getPin() << "\n";

      pq.dequeue();
    }
    catch(const exception& e)
    {
      cout << e.what() << "\n";
    }
  }
  cout << "========= End of Preview ==============\n";
  cout << "\n";
}
