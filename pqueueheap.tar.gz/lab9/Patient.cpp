#include "Patient.h"

#include <string>
using namespace std;

Patient::Patient()
{

}

Patient::Patient(string name, int priority)
{
  m_name = name;
  m_pin = priority;
}

string Patient::getName()
{
  return(m_name);
}

int Patient::getPin()
{
  return(m_pin);
}

bool Patient::operator>(Patient rhs)
{
  return(m_pin > rhs.getPin());
}

bool Patient::operator<(Patient rhs)
{
  return(m_pin < rhs.getPin());
}
