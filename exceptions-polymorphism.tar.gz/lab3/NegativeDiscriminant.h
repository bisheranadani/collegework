#ifndef NEGTIVEDISCRIMINANT_H
#define NEGTIVEDISCRIMINANT_H

#include <stdexcept>

class NegativeDiscriminant: public std::runtime_error
{
public:
  NegativeDiscriminant(const char* msg);
};
#endif
