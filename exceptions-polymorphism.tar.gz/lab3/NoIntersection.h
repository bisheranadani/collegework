#ifndef NOINTERSECTION_H
#define NOINTERSECTION_H

#include <stdexcept>

class NoIntersection: public std::runtime_error
{
public:
  NoIntersection(const char* msg);
};
#endif
