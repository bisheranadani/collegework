#ifndef EXECUTIVE_H
#define EXECUTIVE_H

#include "MathTools.h"

using namespace std;


class Executive
{
public:
  void run();

private:
  MathTools mtools;

};
#endif
