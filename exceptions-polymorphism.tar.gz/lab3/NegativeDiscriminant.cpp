#include "NegativeDiscriminant.h"

NegativeDiscriminant::NegativeDiscriminant(const char* msg): std::runtime_error(msg)
{

}
