#include "MathTools.h"

#include <iostream>
#include <string>
#include <math.h>
using namespace std;

int MathTools::solveQuadratic(double a, double b, double c, double roots[2])  throw (NegativeDiscriminant)
{
  double disc = (b*b) - 4*a*c;

  if(disc < 0)
  {
    throw(NegativeDiscriminant("The discriminant of the quadratic equation you entered is negative\n"));
  }

  else if(disc > 0)
  {
    roots[0] = (-b + sqrt(disc))/(2*a);

    roots[1] = (-b - sqrt(disc))/(2*a);

    return(2);
  }

  else
  {
    roots[0] = -b/(2*a);

    return(1);
  }
}

int MathTools::intersectLineUnitCircle(double d, double e, double f, double xy[2][2])  throw (NoIntersection)
{
  double a = (d*d) + (e*e);
  double b = 2*e*f;
  double c = (f*f) - (d*d);

  try
  {
    int numroots = solveQuadratic(a, b, c, xy[0]);
    if(numroots == 1)
    {
      xy[1][0] = (-e*(xy[0][0]) - f)/d;
    }
    else
    {
      xy[1][0] = (-e*(xy[0][0]) - f)/d;
      xy[1][1] = (-e*(xy[0][1]) - f)/d;
    }
    return(numroots);
  }
  catch(NegativeDiscriminant& e)
  {
    throw(NoIntersection("They don't intersect\n"));
  }

}

void MathTools::roomDimensions(double Area, double Extra, double minRequiredLength, double& width, double& length) throw (CannotDetermineRoomDimensions)
{
  double lengths[2];
  try
  {
    solveQuadratic(1, Extra, -Area, lengths);
    if(lengths[0] > minRequiredLength)
    {
      length = lengths[0];
    }
    else if(lengths[1] > minRequiredLength)
    {
      length = lengths[1];
    }
    else
    {
      throw(CannotDetermineRoomDimensions("Length is shorter than minimum required length\n"));
    }
    width = length + Extra;
  }
  catch(NoIntersection& e)
  {
    throw(CannotDetermineRoomDimensions("Cannot determine room dimensions\n"));
  }

  delete[] lengths;
}
