#include "NoIntersection.h"

NoIntersection::NoIntersection(const char* msg): std::runtime_error(msg)
{
  
}
