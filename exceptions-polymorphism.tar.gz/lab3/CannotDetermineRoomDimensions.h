#ifndef CANNOTDETERMINEROOMDIMENSIONS_H
#define CANNOTDETERMINEROOMDIMENSIONS_H

#include <stdexcept>

class CannotDetermineRoomDimensions: public std::runtime_error
{
public:
  CannotDetermineRoomDimensions(const char* msg);
};
#endif
