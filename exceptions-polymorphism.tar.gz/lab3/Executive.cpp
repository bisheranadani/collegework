#include "Executive.h"

using namespace std;

#include <iostream>
#include <string>
#include <math.h>


void Executive::run()
{

  int i = 0;

  while(i != 4)
  {
    cout << "Choose an option: \n";
    cout << "1) Enter A, B, C for a quadratic equation to be solved\n";
    cout << "2) Enter the d, e, f parameters for a line to be intersected with a unit circle\n";
    cout << "3) Enter Area, Extra, and minRequiredLength for a ballroom\n";
    cout << "4) Quit\n";

    cin >> i;

    try
    {
      if(i == 1)
      {
        int a,b,c = 0;
        cout << "Enter value of a: ";
        cin >> a;
        cout << "Enter value of b: ";
        cin >> b;
        cout << "Enter value of c: ";
        cin >> c;

        double roots[2];
        int f = mtools.solveQuadratic(a, b, c, roots);
        cout << "Equation has " << f << " roots\n";
        cout << "Root: " << roots[0] << "\n";
        if(f > 1)
        {
          cout << "Root: " << roots[1] << "\n";
        }
        // delete[] roots;
      }

      if(i==2)
      {
        int d,e,f = 0;
        cout << "Enter value of d: ";
        cin >> d;
        cout << "Enter value of e: ";
        cin >> e;
        cout << "Enter value of f: ";
        cin >> f;

        double coords[2][2];
        int n = mtools.intersectLineUnitCircle(d, e, f, coords);
        cout << "The lines intersect at " << n << " points\n";
        cout << "Intersection point: " << coords[0][0] << "," << coords[1][0] << "\n";
        if(n > 1)
        {
          cout << "Intersection point: " << coords[0][1] << "," << coords[1][1] << "\n";
        }

        // delete[] coords;
      }

      if(i==3)
      {
        double l = 0;
        double w = 0;
        double a = 0;
        double e = 0;
        double min = 0;

        cout << "Enter the required area: ";
        cin >> a;
        cout << "Enter the extra length: ";
        cin >> e;
        cout << "Enter the minimum length: ";
        cin >> min;

        mtools.roomDimensions(a, e, min, l, w);
        cout << "Length is = " << l << "\n";
        cout << "Width is = " << w << "\n";
      }
    }
    catch(NegativeDiscriminant& e)
    {
      cout << e.what();
    }
    catch(NoIntersection& e)
    {
      cout << e.what();
    }
    catch(CannotDetermineRoomDimensions& e)
    {
      cout << e.what();
    }

  }


  cout << "Bye!\n";
}
