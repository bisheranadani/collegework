#include "Executive.h"
using namespace std;

int main()
{
  Executive exec;
  exec.run();

  return(0);
}
