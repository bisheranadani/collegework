#include "bubbleSort.cpp"
#include "insertionSort.cpp"
#include "mergesort.cpp"
#include "quicksort.cpp"
#include "selectionSort.cpp"

#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <ctime>
using namespace std;

bool checkorder(string ordername)
{
  string* order = new string[3];
  order[0] = "ascending";
  order[1] = "descending";
  order[2] = "random";
  int count = 0;
  for(int i = 0; i < 3; i++)
  {
    if(ordername == order[i]) count++;
  }

  delete[] order;
  if(count != 1)
  {
    return(true);
  }
  else
  {
    return(false);
  }
}

bool checksort(string sortname)
{
  string* sorts = new string[5];
  sorts[0] = "selection";
  sorts[1] = "bubble";
  sorts[2] = "insertion";
  sorts[3] = "quick";
  sorts[4] = "merge";
  int count = 0;
  for(int i = 0; i < 5; i++)
  {
    if(sortname == sorts[i]) count++;
  }
  delete[] sorts;
  if(count != 1)
  {
    return(true);
  }
  else
  {
    return(false);
  }
}

void ascarray(double* array, int size)
{
  double r = 0;
  for(int i = 0; i < size; i++)
  {
    r = 0.001*static_cast<double>(i);
    array[i] = r;
  }
}

void desarray(double* array, int size)
{
  double r = 0;
  for(int i = 0; i < size; i++)
  {
    r = 0.001*static_cast<double>(size - i - 1);
    array[i] = r;
  }
}

void ranarray(double* array, int size)
{
  srand48(time(NULL));
  double r = 0;
  for(int i = 0; i < size; i++)
  {
    r = drand48()*100000.00;
    array[i] = r;
  }
}

void printarray(double* array, int size)
{
  for(int i = 0; i < size; i++)
  {
    cout << array[i] << "\n";
  }
}




int main(int argc, char* argv[])
{
  if(argc < 4)
  {
    cout << "Not enough command line arguments\n";
    return(0);
  }

  if(checkorder(argv[2]))
  {
    cout << "Check the order entered, enter: ascending, descending, or random\n";
    return(0);
  }

  if(checksort(argv[3]))
  {
    cout << "Invalid sort name, enter: selection, bubble, insertion, quick, or merge \n";
    return(0);
  }

  int size = stoi(argv[1]);
  if(size < 50000)
  {
    cout << "Array size must be at least 50000\n";
    return(0);
  }

  cout << "Welcome to sort tester\n";
  cout << "Sorting algorithm: " << argv[3] << "\n";
  cout << "Array sorting: " << argv[2] << "\n";

  double* array = new double[size];
  if(!strcmp(argv[2],"ascending")) ascarray(array, size);
  if(!strcmp(argv[2], "descending")) desarray(array, size);
  if(!strcmp(argv[2], "random")) ranarray(array, size);

  // printarray(array, size);

  clock_t start_time, end_time, elapsed_time;

  if(!strcmp(argv[3], "merge"))
  {
    start_time=clock();
    mergeSort(array, size);
    end_time=clock();
  }
  if(!strcmp(argv[3], "quick"))
  {
    start_time=clock();
    quickSort(array, 0, size -1);
    end_time=clock();
  }

  if(!strcmp(argv[3], "bubble"))
  {
    start_time=clock();
    bubbleSort(array, size);
    end_time=clock();
  }
  if(!strcmp(argv[3], "selection"))
  {
    start_time=clock();
    selectionSort(array, size);
    end_time=clock();
  }
  if(!strcmp(argv[3], "insertion"))
  {
    start_time=clock();
    insertionSort(array, size);
    end_time=clock();
  }

  elapsed_time = end_time - start_time;

  float t = elapsed_time / 1000000.00;

  cout << "Capture time: " << t << "\n";

  // cout << "////////////////////////\n";
  // printarray(array, size);

  delete[] array;
  return(0);
}
