#ifndef POKEMON_H
#define POKEMON_H

#include <string>

using namespace std;

class Pokemon
{
private:
  string m_usname;
  string m_japname;
  int m_pkdx;

public:
  Pokemon();
  Pokemon(string usname, string japname, int pkdx);
  string getUSname();
  string getJAPname();
  int getPkdx();

  void setUSname(string name);
  void setJAPname(string name);
  void setPkdx(int num);


  string upperCase(string name);

  bool operator>(string target);
  bool operator==(string target);

  bool operator>(Pokemon rhs);
  bool operator==(Pokemon rhs);
  bool operator<(Pokemon rhs);

  bool operator=(Pokemon rhs);


};
#endif
