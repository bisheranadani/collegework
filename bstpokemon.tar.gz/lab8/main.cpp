#include "Executive.h"

#include <iostream>
#include <fstream>
#include <string>



int main(int argc, char* argv[])
{
	cout << "main runs\n";

	Executive exec;

	exec.run();

	return (0);
}
