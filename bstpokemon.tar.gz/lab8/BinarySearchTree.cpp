//  Subsetted from:
//  Created by Frank M. Carrano and Tim Henry.
//  Copyright (c) 2013 __Pearson Education__. All rights reserved.

/** @file BinarySearchTree.cpp */
#include <iostream>

#include "BinarySearchTree.h"

// PRIVATE HELPER METHODS - IMPLEMENT THESE

template<typename ItemType, typename KeyType>
BinaryNode<ItemType>* BinarySearchTree<ItemType, KeyType>::copyHelp(const BinaryNode<ItemType>* subTreePtr) const
{
  BinaryNode<ItemType>* copyPtr = nullptr;

  if (subTreePtr != nullptr)
    {
      copyPtr = new BinaryNode<ItemType>(subTreePtr->getItem(), nullptr, nullptr);

      copyPtr->setLeftChildPtr(copyHelp(subTreePtr->getLeftChildPtr()));
      copyPtr->setRightChildPtr(copyHelp(subTreePtr->getRightChildPtr()));
    }

  return(copyPtr);
}

template<typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::destroyTree(BinaryNode<ItemType>* subTreePtr)
{
  if (subTreePtr != nullptr)
  {
    destroyTree(subTreePtr->getLeftChildPtr());
    destroyTree(subTreePtr->getRightChildPtr());

    delete subTreePtr;
  }
}

template<typename ItemType, typename KeyType>
BinaryNode<ItemType>* BinarySearchTree<ItemType,KeyType>::insertInorder(BinaryNode<ItemType>* subTreePtr, BinaryNode<ItemType>* newNodePtr)
{
  if (subTreePtr == nullptr)
  {
    // cout << "Added root";
    return (newNodePtr);
  }
  else if ((subTreePtr->getItem() > newNodePtr->getItem()) || subTreePtr->getItem() == newNodePtr->getItem())
  {
    if(subTreePtr->getLeftChildPtr() == nullptr)
    {
      // cout << "Added left\n";
      subTreePtr->setLeftChildPtr(newNodePtr);
      return(rootPtr);
    }
    else
    {
      // cout << "traversed left\n";
      return(insertInorder(subTreePtr->getLeftChildPtr(), newNodePtr));
    }
  }
  else
  {
    if(subTreePtr->getRightChildPtr() == nullptr)
    {
      // cout << "Added right\n";
      subTreePtr->setRightChildPtr(newNodePtr);
      return(rootPtr);
    }
    else
    {
      // cout << "traversed left";
      return(insertInorder(subTreePtr->getRightChildPtr(), newNodePtr));
    }
  }
}




template<typename ItemType, typename KeyType>
BinaryNode<ItemType>* BinarySearchTree<ItemType, KeyType>::findNode(BinaryNode<ItemType>* subTreePtr, const KeyType& target) const
{
  if (subTreePtr == nullptr)
  {
    return(nullptr);
  }
  else if (subTreePtr->getItem() == target)
  {
    return(subTreePtr);
  }
  else if (subTreePtr->getItem() > target)
  {
    return (findNode(subTreePtr->getLeftChildPtr(), target));
  }
  else
  {
    return (findNode(subTreePtr->getRightChildPtr(), target));
  }
}

template<typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::inorder(BinaryNode<ItemType>* treePtr, void visit(ItemType&)) const
{
  if (treePtr != nullptr)
  {
    ItemType item = treePtr->getItem();
    inorder(treePtr->getLeftChildPtr(), visit);
    visit(item);
    inorder(treePtr->getRightChildPtr(), visit);
  }
}

template<typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::preorder(BinaryNode<ItemType>* treePtr, void visit(ItemType&)) const
{
  if (treePtr != nullptr)
  {
    ItemType item = treePtr->getItem();
    visit(item);
    inorder(treePtr->getLeftChildPtr(), visit);
    inorder(treePtr->getRightChildPtr(), visit);
  }
}

template<typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::postorder(BinaryNode<ItemType>* treePtr, void visit(ItemType&)) const
{
  if (treePtr != nullptr)
  {
    ItemType item = treePtr->getItem();
    postorder(treePtr->getLeftChildPtr(), visit);
    postorder(treePtr->getRightChildPtr(), visit);
    visit(item);
  }
}


template<typename ItemType, typename KeyType>
BinaryNode<ItemType>* BinarySearchTree<ItemType, KeyType>::removeEntry(BinaryNode<ItemType>* subTreePtr, const KeyType& target, bool& isRemoved)
{
    if (subTreePtr == nullptr )
    {
      isRemoved = false;
      return (nullptr);
    }
  else if (subTreePtr->getItem() == target)
    {
      subTreePtr = removeNode(subTreePtr);
      isRemoved = true;
      return(subTreePtr);
    }
  else if (subTreePtr->getItem() > target)
    {
      // cout << "moved left\n";
      BinaryNode<ItemType>* tempPtr = removeEntry(subTreePtr->getLeftChildPtr(), target, isRemoved);
      subTreePtr->setLeftChildPtr(tempPtr);
      return(subTreePtr);
    }
  else
  {
    BinaryNode<ItemType>* tempPtr = removeEntry(subTreePtr->getRightChildPtr(), target, isRemoved);
    subTreePtr->setRightChildPtr(tempPtr);
    return (subTreePtr);
  }
}

template<typename ItemType, typename KeyType>
BinaryNode<ItemType>* BinarySearchTree<ItemType, KeyType>::removeNode(BinaryNode<ItemType>* theNode)
{
    if ( theNode->isLeaf() )
    {
      // cout << "deleted a node\n";
      delete theNode;
      theNode = nullptr;
      return(theNode);
    }
  else if (theNode->hasSinglechild())
    {
      BinaryNode<ItemType>* tempPtr = nullptr;
      if (theNode->getLeftChildPtr() != nullptr)
      {
        tempPtr = theNode->getLeftChildPtr();
      }
      else
      {
        tempPtr = theNode->getRightChildPtr();
        delete theNode;
        theNode = nullptr;
      }
      return (tempPtr);
    }
  else
    {
      ItemType newItem;
      // string usname, japname;
      // int pkdx;

      // BinaryNode<ItemType>* tempPtr = removeSuccessor(theNode->getRightChildPtr(), usname, japname, pkdx);
      BinaryNode<ItemType>* tempPtr = removeSuccessor(theNode->getRightChildPtr(), newItem);
      theNode->setRightChildPtr(tempPtr);
      theNode->setItem(newItem);
      // (theNode->getItem()).setUSname(usname);
      // (theNode->getItem()).setJAPname(japname);
      // (theNode->getItem()).setPkdx(pkdx);

      return (theNode);
    }
}

template<typename ItemType, typename KeyType>
BinaryNode<ItemType>* BinarySearchTree<ItemType, KeyType>::removeSuccessor(BinaryNode<ItemType>* theNode, ItemType& successorValue)
{
  if (theNode->getLeftChildPtr() == nullptr)
    {
      successorValue = theNode->getItem();
      // usname = (theNode->getItem()).getUSname();
      // japname = (theNode->getItem()).getJAPname();
      // pkdx = (theNode->getItem()).getPkdx();
      return(removeNode(theNode));
    }
  else
  {
    return(removeSuccessor(theNode->getLeftChildPtr(), successorValue));
  }
}



template<typename ItemType, typename KeyType>
BinaryNode<ItemType>* BinarySearchTree<ItemType, KeyType>::getRoot()
{
  return(rootPtr);
}



//////////////////////////////////////////////////////////////
//      PUBLIC METHODS BEGIN HERE
//////////////////////////////////////////////////////////////

template<typename ItemType, typename KeyType>
BinarySearchTree<ItemType, KeyType>::BinarySearchTree()
{
  rootPtr = nullptr;
}

//copy constructor
template<typename ItemType, typename KeyType>
BinarySearchTree<ItemType, KeyType>::BinarySearchTree(BinarySearchTree<ItemType, KeyType>& bst)
{
  rootPtr = copyHelp(bst.rootPtr);
}

template<typename ItemType, typename KeyType>
bool BinarySearchTree<ItemType, KeyType>::removeThis(const KeyType& target)
{
  bool success = false;
  rootPtr = removeEntry(rootPtr, target, success);
  return (success);
}

template<typename ItemType, typename KeyType>
BinarySearchTree<ItemType, KeyType>::~BinarySearchTree()
{
   this->destroyTree(rootPtr); // Call inherited method
}  // end destructor


//////////////////////////////////////////////////////////////
//      Public BinaryTreeInterface Methods Section - IMPLEMENT THESE
//////////////////////////////////////////////////////////////

template<typename ItemType, typename KeyType>
bool BinarySearchTree<ItemType, KeyType>::add(const ItemType& newData)
{
  BinaryNode<ItemType>* newNodePtr = new BinaryNode<ItemType>(newData);
  rootPtr = insertInorder(rootPtr, newNodePtr);
	return(true);
}

template<typename ItemType, typename KeyType>
ItemType BinarySearchTree<ItemType, KeyType>::getEntry(const KeyType& aKey) const throw(NotFoundException)
{
  BinaryNode<ItemType>* theNode = findNode(rootPtr, aKey);
  if(theNode != nullptr)
  {
    return(theNode->getItem());
  }
  else
  {
    throw(NotFoundException("The name is not found in the dictionary\n"));
  }
}

template<typename ItemType, typename KeyType>
bool BinarySearchTree<ItemType, KeyType>::contains(const KeyType& aKey) const
{
  BinaryNode<ItemType>* searchPtr = findNode(rootPtr, aKey);
  if(searchPtr == nullptr)
  {
  //   cout << "Name not found in the dictionary\n";
    return(false);
  }
  else
  {
    // print names
    // cout << "Japanese name is: " << (searchPtr->getItem()).getJAPname() << '\n';
    return(true);
  }
}

//////////////////////////////////////////////////////////////
//      Public Traversals Section - IMPLEMENT THESE
//////////////////////////////////////////////////////////////

template<typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::inorderTraverse(void visit(ItemType&) ) const
{
  inorder(rootPtr, visit);
}

template<typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::preorderTraverse(void visit(ItemType&) ) const
{
  preorder(rootPtr, visit);
}

template<typename ItemType, typename KeyType>
void BinarySearchTree<ItemType, KeyType>::postorderTraverse(void visit(ItemType&) ) const
{
  postorder(rootPtr, visit);
}
