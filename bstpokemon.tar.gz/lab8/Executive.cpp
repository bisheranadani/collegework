#include "Executive.h"
// #include "Pokemon.cpp"

#include <iostream>
#include <fstream>

void Executive::visit(Pokemon& pk)
{
  cout << pk.getUSname();
  cout << ", " << pk.getPkdx();
  cout << ", " << pk.getJAPname();
  cout << "\n";
}


void Executive::printFile(Pokemon& pk)
{
  outfile << pk.getUSname();
  outfile << ", " << pk.getPkdx();
  outfile << ", " << pk.getJAPname() << "\n";
}

void Executive::run()
{
  cout << "Welcome to Pokemon dictionary!\n";

  cout << "Enter name of input file: ";

  string fname;
  cin >> fname;

  if(fillTree(fname))
  {

  int c = 0;

  while(c != 7)
  {
    cout << "\n";
    cout << "Choose what you want to do: \n";
    cout << "1) Search the original tree\n";
    cout << "2) Save original tree to a file\n";
    cout << "3) Create a copy which can be edited\n";
    cout << "4) Test add\n";
    cout << "5) Test remove\n";
    cout << "6) Test write to file\n";
    cout << "7) Quit..\n";

    cout << "Choice: ";
    cin >> c;

    if(c == 1)
    {
      choice1();
    }
    if(c == 2)
    {
      string fname;
      cout << "Enter file name: ";
      cin >> fname;

      outfile.open(fname);
      cout << "Printing original tree to " + fname << "\n";
      bst.inorderTraverse(printFile);
      outfile.close();
    }

      if(c == 3)
      {
        run2();
      }

    if(c == 4)
    {
      cout << "Add test-mode: \n";
      testAdds(bst);
    }
    if(c == 5)
    {
      cout << "Remove test-mode: \n";
      testRemoves(bst);
    }
    if(c == 6)
    {
      cout << "Write to file test-mode\n";
      testWriteToFile(bst);
    }

    if(c==7)
    {}

    if(c>7 || c < 1)
    {
      cout << "Choose one of the options\n";
    }


}
}
cout << "Goodbye!\n";
}


bool Executive::fillTree(string fname)
{
  bool success = false;
  string USname, JAPname, strSSN;
  int ssn;

  ifstream infile;
  infile.open(fname);

  if(infile.is_open())
    {
      cout << "we opened\n";
      while(!infile.eof())
      {
        getline(infile, USname, ',');
        getline(infile, strSSN, ',');
        getline(infile, JAPname);
        JAPname.erase(JAPname.length()-1, 1);
        // infile >> JAPname;

        ssn = stoi(strSSN);

        Pokemon pkmn(USname, JAPname, ssn);

        if(bst.add(pkmn))
        {
          visit(pkmn);
        }
        // else
        // {
        // }
      }
      success = true;
   }

  else
  {
    cout << "Input file didnt open\n";
    success = false;
  }

  infile.close();

  return(success);

}

void Executive::testAdds(BinarySearchTree<Pokemon, string> bst)
{
  string usname, japname;
  int pkdx = 0;

  cout << "Enter US name: ";
  cin >> usname;
  cout << "Enter Jap name: ";
  cin >> japname;
  cout << "Enter pkdx: ";
  cin >> pkdx;

  Pokemon pk(usname, japname, pkdx);
  bst.add(pk);

  bst.inorderTraverse(visit);
}

void Executive::testRemoves(BinarySearchTree<Pokemon, string> bst)
{
  string usname;

  cout << "Enter US name: ";
  cin >> usname;

  bst.removeThis(usname);

  bst.inorderTraverse(visit);
}

void Executive::testWriteToFile(BinarySearchTree<Pokemon, string> bst)
{
  string fname;
  cout << "Enter file name: ";
  cin >> fname;

  outfile.open(fname);
  bst.inorderTraverse(printFile);
  outfile.close();
}

void Executive::choice1()
{
  cout << "Enter the US name of a Pokemon: ";
  cin.ignore(1, '\n');
  string name;
  cin >> name;
  if(bst.contains(name))
  {
    cout << "Dictionary definition: ";
    Pokemon p = bst.getEntry(name);
    visit(p);
  }
  else
  {
    cout << "Name not in dictionary\n";
  }
}

void Executive::run2()
{
  BinarySearchTree<Pokemon, string> copybst(bst);
  int c = 0;
  while(c != 5)
  {
  cout << "Copy tree mode running: \n";
  cout << "1) Add to the copy tree\n";
  cout << "2) Remove an entry from the copy tree\n";
  cout << "3) Print to file copy tree\n";
  cout << "4) Print to file original tree\n";
  cout << "5) Quit copy mode..\n";

  cout << "Choice: ";
  cin >> c;

        if(c == 1)
        {
          string usname, japname;
          int pkdx = 0;

          cout << "Enter US name: ";
          cin >> usname;
          cout << "Enter Jap name: ";
          cin >> japname;
          cout << "Enter pkdx: ";
          cin >> pkdx;

          Pokemon pk(usname, japname, pkdx);
          if(copybst.add(pk))
          {
            cout << "Entry added successfully\n";
          }
          else
          {
            cout << "Add failed\n";
          }
        }
        if(c==2)
        {
          string usname;

          cout << "Enter US name: ";
          cin >> usname;

          if(copybst.removeThis(usname))
          {
            cout << "Entry removed\n";
          }
          else
          {
            cout << "Entry removal failed. Entry doesn't exist\n";
          }
        }
        if(c==3)
        {
          cout << "Choose traversal: \n";
          cout << "1) inorder   2) preorder   3)postorder\n";
          cout << "Choice: ";
          int c = 0;
          cin >> c;
          cout << "Enter file name: ";
          string fname;
          cin >> fname;
          cout << "Printing copy tree\n";
          outfile.open(fname);
          if(c == 1)
          {
            copybst.inorderTraverse(printFile);
          }
          if(c == 2)
          {
            copybst.preorderTraverse(printFile);
          }
          if(c == 3)
          {
            copybst.postorderTraverse(printFile);
          }
          outfile.close();
        }

if(c == 4)
{
  cout << "Choose traversal: \n";
  cout << "1) inorder   2) preorder   3)postorder\n";
  cout << "Choice: ";
  int c = 0;
  cin >> c;
  cout << "Enter file name: ";
  string fname;
  cin >> fname;
  cout << "Printing copy tree\n";
  outfile.open(fname);
  if(c == 1)
  {
    bst.inorderTraverse(printFile);
  }
  if(c == 2)
  {
    bst.preorderTraverse(printFile);
  }
  if(c == 3)
  {
    bst.postorderTraverse(printFile);
  }
  outfile.close();
}

if(c==5) {}

if(c>5 || c < 1)
{
  cout << "Choose one of the options\n";
}
}
}
