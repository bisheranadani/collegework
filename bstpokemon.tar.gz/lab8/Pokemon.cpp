#include "Pokemon.h"

#include <string>
#include <cstring>
using namespace std;

Pokemon::Pokemon()
{
  m_pkdx = 0.0001;
}


Pokemon::Pokemon(string usname, string japname, int pkdx)
{
  m_usname = usname;
  m_japname = japname;
  m_pkdx = pkdx;
}

string Pokemon::getUSname()
{
  return(m_usname);
}

string Pokemon::getJAPname()
{
  return(m_japname);
}

int Pokemon::getPkdx()
{
  return(m_pkdx);
}

void Pokemon::setUSname(string name)
{
  m_usname = name;
}

void Pokemon::setJAPname(string name)
{
  m_japname = name;
}

void Pokemon::setPkdx(int num)
{
  m_pkdx = num;
}

bool Pokemon::operator>(string target)
{
  return(m_usname > target);
}

bool Pokemon::operator==(string target)
{
  return(m_usname == target);
}

bool Pokemon::operator>(Pokemon rhs)
{
  // bool isGreater = false;
  // if(m_usname > rhs.getUSname())
  // {
  //   isGreater = true;
  // }
  //
  // this->m_pkdx > rhs.getPkdx()
  // string name = rhs.getUSname();
  // return( this->m_pkdx > rhs.getPkdx() );
  // string upLeftname, upRightname;
  // upLeftname = upperCase(m_usname);
  // upRightname = upperCase(rhs.getUSname());
  //
  // int leftlen, rightlen, looplength;
  // leftlen = upLeftname.length();
  // rightlen = upRightname.length();
  //
  // if(leftlen > rightlen) looplength = rightlen;
  // else { looplength = leftlen; }
  //
  // for(int i = 0; i < looplength; i++)
  // {
  //   if(upLeftname[i] > upRightname[i])
  //   {
  //     return(true);
  //   }
  //
  //   if(upLeftname[i] < upRightname[i])
  //   {
  //     return(false);
  //   }
  // }
  //
  // if(leftlen < rightlen)
  // {
  //   return(true);
  // }
  // else
  // {
  //   return(false);
  // }
  return(m_usname > rhs.getUSname());
}

bool Pokemon::operator==(Pokemon rhs)
{
  // m_pkdx == rhs.getPkdx()
  // string name = rhs.getUSname();
  // return(m_pkdx == rhs.getPkdx());
  // string upLeftname, upRightname;
  // upLeftname = upperCase(m_usname);
  // upRightname = upperCase(rhs.getUSname());
  //
  // int leftlen, rightlen, looplength;
  // leftlen = upLeftname.length();
  // rightlen = upRightname.length();
  //
  // if(leftlen == rightlen)
  // {
  //   looplength = leftlen;
  //   for(int i = 0; i < looplength; i++)
  //   {
  //     if(upLeftname[i] != upRightname[i])
  //     {
  //       return(false);
  //     }
  //   }
  // }
  // else
  // {
  //   return(false);
  // }
  // return(true);
  return(m_usname == rhs.getUSname() );
}

bool Pokemon::operator<(Pokemon rhs)
{
  // m_pkdx == rhs.getPkdx()
  // string name = rhs.getUSname();
  // return( m_pkdx == rhs.getPkdx());
  // string upLeftname, upRightname;
  // upLeftname = upperCase(m_usname);
  // upRightname = upperCase(rhs.getUSname());
  //
  // int leftlen, rightlen, looplength;
  // leftlen = upLeftname.length();
  // rightlen = upRightname.length();
  //
  // if(leftlen > rightlen) looplength = rightlen;
  // else { looplength = leftlen; }
  //
  // for(int i = 0; i < looplength; i++)
  // {
  //   if(upLeftname[i] < upRightname[i])
  //   {
  //     return(true);
  //   }
  //
  //   if(upLeftname[i] > upRightname[i])
  //   {
  //     return(false);
  //   }
  // }
  //
  // if(leftlen > rightlen)
  // {
  //   return(true);
  // }
  // else
  // {
  //   return(false);
  // }
return(m_usname < rhs.getUSname());
}


string Pokemon::upperCase(string name)
{
  int num = name.length();
  string upname = name;

  for(int i = 0; i < num; i++)
  {
    upname[i] = toupper(name[i]);
  }

  return(upname);
}

bool Pokemon::operator=(Pokemon rhs)
{
  m_usname = rhs.getUSname();
  m_japname = rhs.getJAPname();
  m_pkdx = rhs.getPkdx();
  return(true);
}
