#ifndef EXECUTIVE_H
#define EXECUTIVE_H

// #include "BinaryNode.h"
#include "BinarySearchTree.h"
#include "Pokemon.h"
#include <fstream>
#include <iostream>

static ofstream outfile;

// void visit(Pokemon& pk);


class Executive
{
private:
  BinarySearchTree<Pokemon, string> bst;
  static void visit(Pokemon& pk);
  static void printFile(Pokemon& pk);



public:

  void run();
  void run2();
  bool fillTree(string fname);
  void testAdds(BinarySearchTree<Pokemon, string> bst);
  void testRemoves(BinarySearchTree<Pokemon, string> bst);
  void testWriteToFile(BinarySearchTree<Pokemon, string> bst);
  void choice1();



  // void printoutfile(string fname);
};
#endif
