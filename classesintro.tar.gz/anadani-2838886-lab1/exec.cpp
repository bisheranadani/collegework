#include "exec.h"
#include <string>
#include <fstream>
#include <iostream>
#include <limits>

using namespace std;

exec::exec(string filename)
{
  infile.open(filename);
  infile >> filesize;

  array = new vrr[filesize];

  int i = 0;
  int j = 0;
  string s_temp = "\0";
  int i_temp = 0;

  for(i = 0; i < filesize; i++)
  {
    for(j = 0; j < 4; j++)
    {
      s_temp = "\0";
      if(j == 0)
      {
        infile >> s_temp;
         array[i].setFname(s_temp);
      }
      if(j == 1)
      {
        infile >> s_temp;
        array[i].setLname(s_temp);
      }
      if(j == 2)
      {
        infile >> i_temp;
        array[i].setAge(i_temp);
      }
      if(j == 3)
      {
        infile >> s_temp;
        array[i].setAffil(s_temp);
      }
    }
  }
  infile.close();
}

exec::~exec()
{
  delete[] array;
}

void exec::run()
{
  int choice = 0;

  while(choice != 5)
  {
    cout << "\n";
    cout << "Choose an option: \n";
    cout << "1) Query last name \n";
    cout << "2) Query age range \n";
    cout << "3) Query affiliations \n";
    cout << "4) Report number of people with affiliation \n";
    cout << "5) Quit \n";
    cout << "\nEnter the number corresponding to the command: ";

    cin >> choice;

    cout << "\n";

    while(cin.fail() || choice > 5 || choice < 1 )
    {
      cin.clear();
      cin.ignore(numeric_limits<streamsize>::max(), '\n');
      cout << "Please choose a correct option: ";
      cin >> choice;
    }

    if(choice == 1)
    {
      printname();
    }

    if(choice == 2)
    {
      printage();
    }

    if(choice == 3)
    {
      printaffil();
    }

    if(choice == 4)
    {
      countaffil();
    }
    }
  }


  void exec::printname() const
  {
    cout << "Enter the last name: ";
    string name = "\0";
    cin >> name;
    int i = 0;

    cout << "\nRecords: \n";

    for(i = 0; i < filesize; i++)
    {
        if(array[i].getLname() == name)
        {
          recprint(i);
        }
      }
  }

  void exec::printage() const
  {
    int l = 0;
    int h = 0;

    cout << "Enter the minimum age limit: ";
    cin >> l;
    while(cin.fail() || l < 0)
    {
      cin.clear();
      cin.ignore(numeric_limits<streamsize>::max(), '\n');
      cout << "Please enter a correct age: ";
      cin >> l;
    }

    cout << "Enter the maximum age limit: ";
    cin >> h;
    while(cin.fail() || h < l)
    {
      cin.clear();
      cin.ignore(numeric_limits<streamsize>::max(), '\n');
      cout << "Please enter a correct age: ";
      cin >> h;
    }

    cout << "\nRecords: \n";

    int i = 0;
    for(i = 0; i < filesize; i++)
    {
      if(array[i].getAge() <= h && array[i].getAge() >= l)
      {
        recprint(i);
      }
    }
  }

  void exec::printaffil() const
  {
    cout << "Choose the party affiliation: \n";
    cout << "1) Democrat\n2) Green\n3) Independent\n4) Libertarian\n5) Republican\n6) Unspecified\n";

    int c = 0;
    cin >> c;

    while(cin.fail() || c > 6 || c < 1 )
    {
      cin.clear();
      cin.ignore(numeric_limits<streamsize>::max(), '\n');
      cout << "Please choose a correct option: ";
      cin >> c;
    }

    string choice = "\0";

    if(c == 1)
    {
      choice = "Democrat";
    }
    if(c == 2)
    {
      choice = "Green";
    }
    if(c == 3)
    {
      choice = "Independent";
    }
    if(c == 4)
    {
      choice = "Libertarian";
    }
    if(c == 5)
    {
      choice = "Republican";
    }
    if(c == 6)
    {
      choice = "Unspecified";
    }

    cout << "\nRecords: \n";

    int i = 0;
    for(i = 0; i < filesize; i++)
    {
      if(array[i].getAffil() == choice )
      {
        recprint(i);
      }
    }
  }

  void exec::countaffil() const
  {
    cout << "Choose the party affiliation: \n";
    cout << "1) Democrat\n2) Green\n3) Independent\n4) Libertarian\n5) Republican\n6) Unspecified\n";

    int c = 0;
    cin >> c;

    while(cin.fail() || c > 6 || c < 1 )
    {
      cin.clear();
      cin.ignore(numeric_limits<streamsize>::max(), '\n');
      cout << "Please choose a correct option: ";
      cin >> c;
    }


    string choice = "\0";

    if(c == 1)
    {
      choice = "Democrat";
    }
    if(c == 2)
    {
      choice = "Green";
    }
    if(c == 3)
    {
      choice = "Independent";
    }
    if(c == 4)
    {
      choice = "Libertarian";
    }
    if(c == 5)
    {
      choice = "Republican";
    }
    if(c == 6)
    {
      choice = "Unspecified";
    }

    cout << "\n";

    int n = 0;
    int i = 0;
    for(i = 0; i < filesize; i++)
    {
      if(array[i].getAffil() == choice )
      {
        n++;
      }
    }

    cout << "The number of voters registered for the " << choice << " party is: ";
    cout << n << "\n";
  }

  void exec::recprint(int i) const
  {
    cout << array[i].getFname() << " ";
    cout << array[i].getLname() << "; ";
    cout << "Age: " << array[i].getAge() << "; ";
    cout << "Registered as " << array[i].getAffil() << "\n";
  }
