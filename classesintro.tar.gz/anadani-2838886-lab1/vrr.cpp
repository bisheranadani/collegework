#include "vrr.h"

using namespace std;

void vrr::setFname(string n)
{
  fname = n;
}

string vrr::getFname() const
{
  return(fname);
}

void vrr::setLname(string n)
{
  lname = n;
}

string vrr::getLname() const
{
  return(lname);
}

void vrr::setAge(int a)
{
  age = a;
}

int vrr::getAge() const
{
  return(age);
}

void vrr::setAffil(string a)
{
  affil = a;
}

string vrr::getAffil() const
{
  return(affil);
}
