#include <iostream>
#include <fstream>
#include <string>

#include "vrr.h"
#include "exec.h"

int main (int argc, char* argv[])
{
  ifstream infile;
  infile.open(argv[1]);
  if(infile.is_open())
  {
    infile.close();
    exec exc(argv[1]);
    exc.run();
  }
  else
  {
    cout << "Filename no bueno.\n";
  }


    cout << "Thank you\n";
    return (0);
}
