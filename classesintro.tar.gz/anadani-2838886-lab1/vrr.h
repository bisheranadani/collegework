#ifndef VRR_H
#define VRR_H

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

class vrr
{
private:
  string fname;
  string lname;
  int age;
  string affil;

public:
  void setFname(string n);
  string getFname() const;

  void setLname(string n);
  string getLname() const;

  void setAge(int a);
  int getAge() const;

  void setAffil(string a);
  string getAffil() const;
};
#endif
