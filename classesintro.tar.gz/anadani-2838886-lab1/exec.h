#ifndef EXEC_H
#define EXEC_H

#include "vrr.h"
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

class exec
{
private:
  ifstream infile;
  int filesize;
  vrr* array;

public:
  exec(string fname);
  ~exec();
  void run();
  void printname() const;
  void printage() const;
  void printaffil() const;
  void countaffil() const;
  void recprint(int i) const;

};
#endif
