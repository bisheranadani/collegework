#include "Executive.h"

using namespace std;
#include <iostream>
#include <string>
#include <fstream>

void Executive::run(string file)
{
  ifstream infile;

  infile.open(file);

  if(infile.is_open())
  {

  string s1,s2;

  while(infile >> s1)
  {
    if( infile.eof() ) break;

    if(s1 == "WAIT" )
    {
      // cout << "in wait\n";
      infile >> s2;
      // cout << "read name\n";
      wait(s2);
      // cout << "wait ex\n";
    }

    if(s1 == "PICK_UP")
    {
      pickup();
    }

    if(s1 == "DROP_OFF")
    {
      infile >> s2;
      int off = stoi(s2);
      try
      {
      dropoff(off);
    }
    catch(PreconditionViolationException& e)
    {
      cout << e.what();
    }
    }
    if(s1 == "INSPECTION")
    // else
    {
      inspection();
    }
  }

  infile.close();
}
else
{
  cout << "Input file doesn't open\n";
}
}

void Executive::wait(string name)
{
  line.enqueue(name);
}

void Executive::pickup()
{
  while(!elev.isFull())
  {
    elev.push(line.peekFront());
    line.dequeue();
  }
}

void Executive::dropoff(int out)
{
  try
  {
    for(int i = 0; i < out; i++)
    {
      elev.pop();
    }
  }
  catch(std::exception& e)
  {
    cout << e.what();
  }
}

void Executive::inspection()
{
  cout << "The elevator is ";
  if(elev.isEmpty())
  {
    cout << "empty\n";
  }
  else
  {
    cout << "not empty\n";
  }

  try
  {
  cout << elev.peek() << " will be the next person to leave the elevator\n";
}
catch(PreconditionViolationException& e)
{
  // cout << e.what();
  cout << "No one is in the elevator\n";
}
try
{
  cout << line.peekFront() << " will be the next person to get on the elevator\n";
}
catch(PreconditionViolationException& e)
{
  // cout << e.what();
  cout << "No one is waiting for the elevator\n";
}
}
