#include <iostream>
#include <string>
#include <fstream>
using namespace std;

#include "Executive.h"

int main(int argc, char* argv[])
{
  cout << "Welcome to elevator simulator!\n";

  if(argc < 2)
  {
    cout << "Please enter input file name as a command line argument \n";
    return(0);
  }

  string name = argv[1];
  Executive exec;
  exec.run(name);

  return(0);
}
