#include "Queue.h"

using namespace std;

template <typename T>
Queue<T>::Queue()
{
  m_front = nullptr;
}

template <typename T>
bool Queue<T>::isEmpty() const
{
  //linkedlist isempty
  if(m_front == nullptr)
  {
    return(true);
  }
  return(false);
}

template <typename T>
void Queue<T>::enqueue(const T value)
{
  //linkedlist addBack
  if(isEmpty())
  {
    Node<T>* add = new Node<T>(value);
    m_front = add;
  }
  else
  {
    Node<T>* temp = m_front;
    while(temp->getNext() != nullptr)
    {
      temp = temp->getNext();
    }
    Node<T>* add = new Node<T>(value);
    temp->setNext(add);
  }
}

template <typename T>
void Queue<T>::dequeue() throw(PreconditionViolationException)
{
//   //linkedlist removeFront
  if(isEmpty())
  {
    throw(PreconditionViolationException("Can't dequeue, queue is empty\n"));
  }
  else
  {
    Node<T>* temp = m_front;
    m_front = temp->getNext();
    delete temp;
  }
}
//
template <typename T>
T Queue<T>::peekFront() const throw(PreconditionViolationException)
{
  if(isEmpty())
  {
    throw(PreconditionViolationException("Can't peek, queue is empty\n"));
  }
  else
  {
    return(m_front->getValue());
  }
}

template <typename T>
Queue<T>::~Queue()
{
  //delete queue
    while(!isEmpty())
    {
      dequeue();
    }
}
