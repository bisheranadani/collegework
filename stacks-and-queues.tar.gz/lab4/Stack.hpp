#include "Stack.h"

using namespace std;
#include <iostream>

template <typename T>
Stack<T>::Stack()
{
  // m_stackarray = new T[7];
  index = 0;
}

template <typename T>
bool Stack<T>::isEmpty() const
{
  bool isEmp = false;
  if(index == 0)
  {
    isEmp = true;
  }
  return(isEmp);
}

template <typename T>
bool Stack<T>::isFull() const
{
  bool isF = false;
  if(index >= 7)
  {
    isF = true;
  }
  return(isF);
}

template <typename T>
void Stack<T>::push(const T value) throw(PreconditionViolationException)
{
  if(index >= 7)
  {
    throw(PreconditionViolationException("Can't push, stack is full\n"));
  }
  else
  {
    m_stackarray[index] = value;
    index++;
  }
}

template <typename T>
void Stack<T>::pop() throw(PreconditionViolationException)
{
  if(index <= 0)
  {
    throw(PreconditionViolationException("Can't pop, stack is empty\n"));
  }
  else
  {
    index--;
  }
}

template <typename T>
T Stack<T>::peek() const throw(PreconditionViolationException)
{
  if(index <= 0)
  {
    throw(PreconditionViolationException("Can't peek, stack is empty\n"));
  }
  else
  {
    return(m_stackarray[index-1]);
  }
}

template <typename T>
Stack<T>::~Stack()
{
  //  delete m_stackarray;
}
