#ifndef STACK_H
#define STACK_H

#include "StackInterface.h"

using namespace std;
#include <iostream>

template <typename T>
class Stack: public StackInterface<T>
{
public:
  Stack();
  bool isEmpty() const;
  bool isFull() const;
  void push(const T value) throw(PreconditionViolationException);
  void pop() throw(PreconditionViolationException);
  T peek() const throw(PreconditionViolationException);
  ~Stack();

private:
  T m_stackarray[7];
  int index;
};
#include "Stack.hpp"
#endif
