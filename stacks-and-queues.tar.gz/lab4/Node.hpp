#include "Node.h"

#include <iostream>
#include <string>
#include <cstddef>
using namespace std;

template <typename T>
Node<T>::Node(T value)
{
  entry = value;
  next = nullptr;
}

template <typename T>
T Node<T>::getValue() const
{
  return(entry);
}

template <typename T>
void Node<T>::setValue(T value)
{
  entry = value;
}

template <typename T>
Node<T>* Node<T>::getNext() const
{
  return(next);
}

template <typename T>
void Node<T>::setNext(Node<T>* ptr)
{
  next = ptr;
}
