#ifndef QUEUE_H
#define QUEUE_H

#include "QueueInterface.h"
#include "Node.h"

template <typename T>
class Queue: public QueueInterface<T>
{
public:
  Queue();
  bool isEmpty() const;
  void enqueue(const T value);
  void dequeue() throw(PreconditionViolationException);
  T peekFront() const throw(PreconditionViolationException);
  ~Queue();

private:
  Node<T>* m_front;
};
#include "Queue.hpp"
#endif
