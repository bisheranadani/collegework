#ifndef EXECUTIVE_H
#define EXECUTIVE_H

#include "Stack.h"
#include "Queue.h"

#include <string>

class Executive
{
public:
  void run(string file);
  void wait(string name);
  void pickup();
  void dropoff(int out);
  void inspection();


private:
  Stack<string> elev;
  Queue<string> line;
};
#endif
