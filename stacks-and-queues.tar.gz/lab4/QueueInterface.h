#ifndef QUEUEINTERFACE_H
#define QUEUEINTERFACE_H

#include "PreconditionViolationException.h"

template <typename T>
class QueueInterface
{
public:
  virtual ~QueueInterface() {};
  virtual bool isEmpty() const = 0;
  virtual void enqueue(const T value) = 0;
  virtual void dequeue() throw(PreconditionViolationException) = 0;
  virtual T peekFront() const throw(PreconditionViolationException) = 0;
};
#endif
