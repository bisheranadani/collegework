#ifndef NODE_H
#define NODE_H

#include <iostream>
#include <string>
using namespace std;

template <typename T>
class Node
{
public:
  Node(T value);
  T getValue() const;
  void setValue(T value);
  Node<T>* getNext() const;
  void setNext(Node<T>* ptr);

private:
  T entry;
  Node<T>* next;
};
#include "Node.hpp"
#endif
