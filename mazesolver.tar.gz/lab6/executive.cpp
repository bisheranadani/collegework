#include "executive.h"
#include "MazeCreationException.h"
#include "mazereader.h"
#include "mazewalker.h"
#include "mazewalker.cpp"
#include "mazereader.cpp"

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

void Executive::run(string file)
{
  cout << "Welcome to maze solver!\n";

  try
  {
    MazeReader mzrdr(file);

    MazeWalker mzwlkr(mzrdr.getMaze(), mzrdr.getStartRow(), mzrdr.getStartCol(), mzrdr.getRows(), mzrdr.getCols());

    cout << "Starting position: " << mzrdr.getStartRow() << ", " << mzrdr.getStartCol() << "\n";
    cout << "Size: " << mzrdr.getRows() << ", " << mzrdr.getCols() << "\n";

    if(mzwlkr.walkMaze())
    {
      printmazearray(mzrdr.getMaze(), mzwlkr.getVisitedRows(), mzwlkr.getVisitedCols());
      cout << "\n \n \n";
      printvisitedarray(mzwlkr.getVisited(), mzwlkr.getVisitedRows(), mzwlkr.getVisitedCols());

      cout << "We Escaped! \n";
    }
    else
    {
      printmazearray(mzrdr.getMaze(), mzwlkr.getVisitedRows(), mzwlkr.getVisitedCols());
      // cout << "\n \n \n";
      // printvisitedarray(mzwlkr.getVisited(), mzwlkr.getVisitedRows(), mzwlkr.getVisitedCols());
      cout << "No exit!\n";
    }

  }
  catch(MazeCreationException& e)
  {
    cout << e.what();
  }
}

void Executive::printvisitedarray(const int* const* array, int rows, int cols) const
{
  for(int i = 0; i < rows; i++)
  {
    for(int j = 0; j < cols; j++)
    {
      cout << array[i][j] << "     ";
    }
    cout << "\n";
  }
}

void Executive::printmazearray(const char* const* array, int rows, int cols) const
{
  for(int i = 0; i < rows; i++)
  {
    for(int j = 0; j < cols; j++)
    {
      cout << array[i][j] << "     ";
    }
    cout << "\n";
  }
}
