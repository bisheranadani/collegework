#include "mazewalker.h"

#include <iostream>
using namespace std;

MazeWalker::MazeWalker(const char* const* mazePtr, int startRow, int startCol, int rows, int cols)
{
  m_maze = mazePtr;
  m_rows = rows;
  m_cols = cols;
  m_startRow = startRow;
  m_startCol = startCol;

  m_curStep = 0;
  goalreachedflag = false;

  m_visited = new int*[rows];

  for(int i = 0; i < rows; i++)
  {
    m_visited[i] = new int[cols];
    for(int j = 0; j < cols; j++)
    {
      m_visited[i][j] = 0;
    }
  }

}

MazeWalker::~MazeWalker()
{
  for(int i = 0; i < m_rows; i++)
  {
    delete[] m_visited[i];
  }

  delete[] m_visited;
}

const int* const* MazeWalker::getVisited() const
{
  return(m_visited);
}

int MazeWalker::getVisitedRows() const
{
  return(m_rows);
}

int MazeWalker::getVisitedCols() const
{
  return(m_cols);
}

const char* const* MazeWalker::getMaze() const
{
  return(m_maze);
}

bool MazeWalker::isGoalReached() const
{
    return(goalreachedflag);
}


void MazeWalker::solvemaze(int curRow, int curCol)
{
  m_visited[curRow][curCol] = m_curStep;

  // for(int i = 0; i < m_rows; i++)
  // {
  //   for(int j = 0; j < m_cols; j++)
  //   {
  //     cout << m_visited[i][j] << "    ";
  //   }
  //   cout << "\n";
  // }
  //
  //
  // cout << curRow << ", " << curCol << '\n';
  // cout << "\n \n";


  int rowUp = curRow -1;
  int colRight = curCol + 1;
  int rowDown = curRow + 1;
  int colLeft = curCol - 1;

  if(m_maze[curRow][curCol] == 'E')
  {
    goalreachedflag = true;
  }

  m_curStep++;

  if(rowUp >= 0 && m_visited[rowUp][curCol] == 0 && !isGoalReached() && m_maze[rowUp][curCol] != 'W')
  {
    // m_curStep++;
    solvemaze(rowUp, curCol);
  }

  if(colRight <= (m_cols - 1) && m_visited[curRow][colRight] == 0 && !isGoalReached() && m_maze[curRow][colRight] != 'W')
  {
    // m_curStep++;
    solvemaze(curRow, colRight);
  }

  if(rowDown <= (m_rows - 1) && m_visited[rowDown][curCol] == 0 && !isGoalReached() && m_maze[rowDown][curCol] != 'W')
  {
    // m_curStep++;
    solvemaze(rowDown, curCol);
  }

  if(colLeft >= 0 && m_visited[curRow][colLeft] == 0 && !isGoalReached() && m_maze[curRow][colLeft] != 'W')
  {
    // m_curStep++;
    solvemaze(curRow, colLeft);
  }

  if(!isGoalReached())
  {
    m_visited[curRow][curCol] = 0;
    m_curStep--;
  }
}

bool MazeWalker::walkMaze()
{
  m_curStep = 1;
  // int stRow = m_startRow;
  // int stCol = m_startCol;
  solvemaze(m_startRow , m_startCol);

  bool wm = isGoalReached();
  return(wm);
}
