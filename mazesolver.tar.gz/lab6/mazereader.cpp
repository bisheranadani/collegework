#include "mazereader.h"

using namespace std;
#include <iostream>
#include <fstream>
#include <string>

MazeReader::MazeReader(string file) throw(MazeCreationException)
{
  ifstream infile;
  infile.open(file);
  if(infile.is_open())
  {
    infile >> r_rows;
    infile >> r_cols;
    infile >> r_startrow;
    infile >> r_startcol;

    if(r_rows > 0 && r_cols > 0)
    {
      r_maze = new char*[r_rows];
      for (int i = 0; i < r_rows; i++)
      {
        r_maze[i] = new char[r_cols];
      }
    }
    else
    {
      throw(MazeCreationException("Error: Rows or Columns are less than 1\n"));
    }
  }
  else
  {
    throw(MazeCreationException("Error: file cannot be opened or does not exist\n"));
  }

  for (int i = 0; i < r_rows; i++)
  {
    for(int j = 0; j < r_cols; j++)
    {
      infile >> r_maze[i][j];
    }
  }

  if(r_startrow >= r_rows || r_startcol >= r_cols || r_startcol < 0 || r_startrow < 0 || r_maze[r_startrow][r_startcol] != 'P')
  {
    throw (MazeCreationException("Error: invalid starting position \n"));
  }

  infile.close();

  // readMaze(file);
}

MazeReader::~MazeReader()
{
  for(int i = 0; i < r_rows; i++)
  {
    delete[] r_maze[i];
  }

  delete[] r_maze;
}

const char* const* MazeReader::getMaze() const
{
  return(r_maze);
}

int MazeReader::getCols() const
{
  return(r_cols);
}

int MazeReader::getRows() const
{
  return(r_rows);
}

int MazeReader::getStartCol() const
{
  return(r_startcol);
}

int MazeReader::getStartRow() const
{
  return(r_startrow);
}

// void MazeReader::readMaze(string file) throw(MazeCreationException)
// {
//   ifstream infile;
//   infile.open(file);
//   for (int i = 0; i < r_rows; i++)
//   {
//     for(int j = 0; j < r_cols; j++)
//     {
//       infile >> r_maze[i][j];
//     }
//   }
//
//   infile.close();
//
//   if(r_maze[r_startrow - 1][r_startcol - 1] != 'P')
//   {
//     throw (MazeCreationException("Error: Starting position is not a passage \n"));
//   }
// }
