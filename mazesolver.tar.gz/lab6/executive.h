#ifndef EXECUTIVE_H
#define EXECUTIVE_H

#include "mazereader.h"
#include "mazewalker.h"

using namespace std;

class Executive
{
public:
  void run(string file);
  void printvisitedarray(const int* const* array, int rows, int cols) const;
  void printmazearray(const char* const* array, int rows, int cols) const;


};
#endif
