#include "MazeCreationException.h"

MazeCreationException::MazeCreationException(const char* msg): std::runtime_error(msg)
{

}
