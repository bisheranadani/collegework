#ifndef MAZEREADER_H
#define MAZEREADER_H

#include "MazeCreationException.h"
using namespace std;

class MazeReader
{
public:
	/**
	*	@post A MazeReader is created. A 2D char array is allocated with the maze information.
	*	@throws MazeCreationExecption
	*
	*/
	MazeReader(string file)  throw(MazeCreationException);

	/**
	*	@post The maze is deallocated.
	*/
	~MazeReader();

	/**
	*	@pre the file was formatting and read in correctly
	*	@return Returns pointer to the maze
	*/
	const char* const* getMaze() const;

	/**
	*	@pre the file was formatted and read in correctly
	*	@returns the number of columns listed in the file
	*/
	int getCols() const;

	/**
	*	@pre the file was formatted and read in correctly
	*	@returns the number of rows listed in the file
	*/
	int getRows() const;

	/**
	*	@pre the file was formatted and read in correctly
	*	@returns the starting column
	*/
	int getStartCol() const;

	/**
	*	@pre the file was formatted and read in correctly
	*	@returns the starting row
	*/
	int getStartRow() const;

	private:
	/**
	*	@pre the file is properly formatted
	*	@post the characters representing the maze are stored
	*/
	// void readMaze(string file)	throw (MazeCreationException);
	char** r_maze;
	int r_cols;
	int r_rows;
	int r_startrow;
	int r_startcol;
};
#endif
